VittixAutoUpdater signed manifest test fixture.
